package state;

public interface StateView {

}
