package state;

public interface BoardView {

}
