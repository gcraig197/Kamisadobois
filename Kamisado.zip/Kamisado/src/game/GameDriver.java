package game;

public class GameDriver {

	public GameDriver() {
	// TODO Auto-generated constructor stub
}
	public void play(){
		
	}
}
