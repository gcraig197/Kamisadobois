package state;

public class XTerm {

	public XTerm() {
	// TODO Auto-generated constructor stub
}
	
	public void read(){
		
	}
	
	public void write(){
		
	}
	
	public void interrupt(){
		
	}

}
