package game;

public class Board {
	
	
	public Board() {
		Piece[][] board = new Piece[8][8];
		
		
}
	
	public void make(String move){
		
	}

	public void gameOver(){
		
	}
}
