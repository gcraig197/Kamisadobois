
public interface Observer {

	public default void update(){
		
	}
}
