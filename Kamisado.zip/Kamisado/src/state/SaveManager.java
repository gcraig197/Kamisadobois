package state;

public class SaveManager {
public SaveManager() {
	// TODO Auto-generated constructor stub
}

public void save(State s){
	
}

public void restore(){
	
}

}
