package state;

public class State {

	public State() {
	// TODO Auto-generated constructor stub
}
	public boolean legal( String move){
		
		return false;
	}
	
	public void make(String move){
		
	}
}
