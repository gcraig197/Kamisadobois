package game;

public class EasyAIPlayer {

}
