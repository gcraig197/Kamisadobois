package game;

public class SpeedGameDriver {
public SpeedGameDriver() {
	// TODO Auto-generated constructor stub
}

public void onTimeOut(){
	
}

public void setTimeLimit(){
	
}
}
