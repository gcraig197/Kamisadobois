package game;

public enum Piece {

	ORANGE,
	DBLUE,
	LBLUE,
	PINK,
	YELLOW,
	RED,
	GREEN,
	BROWN;
	
	
}
