package game;

public class MathReport {

}
