package game;

public class Player {
public Player() {
	// TODO Auto-generated constructor stub
}

public void getMove(Board board){
	
}

public void interrupt(){
	
}

}
